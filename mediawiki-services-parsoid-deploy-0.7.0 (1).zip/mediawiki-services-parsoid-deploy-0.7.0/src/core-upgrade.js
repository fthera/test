'use strict';
require('core-js/shim');
